package com.example.flutter5

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
